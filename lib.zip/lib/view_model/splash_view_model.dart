import 'dart:async';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:quizzy_app/Service/Firebase/social_service/repository_implementaion_service/apple_repository_service.dart';
import 'package:quizzy_app/Service/Firebase/social_service/repository_implementaion_service/facebook_repository_service.dart';
import 'package:quizzy_app/Service/Firebase/social_service/repository_implementaion_service/google_repository_Service.dart';
import 'package:quizzy_app/Service/Firebase/social_service/repository_implementaion_service/social_repository_manger_service.dart';
import 'package:quizzy_app/Service/api/repository_implementaion_service/auth_repository_service.dart';
import 'package:quizzy_app/Service/api/repository_implementaion_service/profile_repository_service.dart';
import 'package:quizzy_app/Service/local/auth_route_service.dart';
import 'package:quizzy_app/Service/local/auth_token_service.dart';
import 'package:quizzy_app/Service/local/cache_notification_service.dart';
import 'package:quizzy_app/Service/local/cache_subject_service.dart';
import 'package:quizzy_app/Service/local/cache_user_service.dart';
import 'package:quizzy_app/Service/nottification/push_notification_service.dart';
import 'package:quizzy_app/model/user_model.dart';
import 'package:quizzy_app/utils/constant.dart';
import 'package:quizzy_app/utils/end_point.dart';
import 'package:quizzy_app/utils/general_utils.dart';
import 'package:quizzy_app/utils/routes.dart';
import 'package:quizzy_app/utils/snack_bar_helper.dart';

import '../Service/Firebase/social_service/repository/social_repository.dart';

class SplashViewModel extends GetxController {
  String splashTextInit = "";
  @override
  void onInit() async {
    // TODO: implement onInit
    super.onInit();
    await PushNotificationService().initPushNotification();
    Timer(const Duration(milliseconds: 30), () async {
      bool result = AuthRouteService.instance.readRoute();
      debugPrint("-" * 50);
      debugPrint("Route Exit : $result");
      debugPrint("-" * 50);
      if (result) {
        _getProfileService();
      } else {
        Get.offAllNamed(Routes.loginView);
        // if the Account Deleted from the System
        await _logout();
      }
      // await PushNotificationService().initPushNotification();
    });
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() async {
    super.onClose();
  }

  void _getProfileService() {
    PofileRepositoryService().getProfile().then((value) async {
      if (value.data!.isActive != null && value.data!.isActive!) {
        await CacheUserService.instance
            .updateUser(user: value.data!); // to cache the User Object
        Get.offAllNamed(Routes.bottomNavgation);
      } else {
        Get.offAllNamed(Routes.loginView);
      }
    }).catchError((e) {
      debugPrint(e);
      // String name = CacheUserService.instance.getUser().name!;
      // String contactUs = EndPoint.contactUs;
      // SnackBarHelper.instance.showMessage(
      //     erro: true,
      //     isEnglish: false,
      //     milliseconds: 35000,
      //     message:
      //         "اهلا $name \n لقد تم حذف حسابك يرجي الإتصال بنا علي هذا الموقع \n $contactUs");
      Get.offAllNamed(Routes.loginView);
    });
  }

  Future<void> _logout() async {
    User _user = CacheUserService.instance.getUser();

    await Future.wait([
      CacheUserService.instance.deleteUser(),
      CacheNotificationService.instance.delete(),
      // CacheThemeService.instance.deleteTheme(),
      AuthTokenService.instance.delete(),
      CacheSubjectService.instance.deleteSubjects(),
      AuthRouteService.instance.logout(),
    ])
        .then((value) => debugPrint("Delete the All Cache"))
        .catchError((e, s) => debugPrint(s.toString()));

    if (_user.providerType != null) {
      SocialRepository socialRepository = _getObjectTypeOfSocaiLogin(
          socialMediaType: GeneralUtils.instance
              .convertSocialMediaStringToEnum(_user.providerType!));

      await SocialRepositoryMangerService()
          .logout(socialRepository); // apply Polymarphism

      debugPrint("-" * 50);
      debugPrint("Log Out form ${_user.providerType!}");
      debugPrint("-" * 50);
    }
  }

  SocialRepository _getObjectTypeOfSocaiLogin(
      {required SocialMediaType socialMediaType}) {
    if (socialMediaType == SocialMediaType.apple) {
      return AppleRepositoryService();
    } else if (socialMediaType == SocialMediaType.google) {
      return GoogleRepositoryService();
    } else {
      //   return FacebookRepositoryService();
      // remove a Google and add Facebook
      return FacebookRepositoryService();
    }
  }
}
